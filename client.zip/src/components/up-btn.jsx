import React from "react";

function UpBtn(){
    return(
        <button class="up-btn"><a href="#header">
            <span class="iconify" data-icon="akar-icons:chevron-up" data-width="40" data-height="40"></span>
            <span class="up">بالا</span>
        </a></button>
    )
}

export default UpBtn;