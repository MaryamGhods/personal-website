import React from "react";

function SectionSeprator(prop){
    return(
        <div class="between-sections" >
            <img src={prop.src} alt="" />
        </div>
    )
}

export default SectionSeprator;